This code simulates the response of a CA1 pyramidal cell to synaptic
input using a recontructed cell morphology and  realistic synaptic
input spread throughout the dendritic arbor.  A graphical user
interface (GUI) allows the user to  manipulate the relevant paramters
with ease.

For the code to function properly the following files should be
present:

(1) Jarsky_Gating_Axon.nrn:  Generates an axon.  
(2) Jarsky_Gating_Init.hoc:  Set passive and active cell properties.  
(3) Jarsky_Gating_MainProgram_Basic.hoc:  Main program for the basic version.  
(4) Jarsky_Gating_Morphology.hoc:  Recontructed cell morphology.  
(5) Jarsky_Gating_Synapses_Basic.hoc:  Creates and inserts synapses.  
(6) kadist.mod 
(7) kaprox.mod 
(8) kdrca1.mod 
(9) na3.mod 
(10) nax.mod 
(11) plotdiam.hoc 
(12) vmax.mod

In addition, the following files provide for additional flexibility in
the simulations at the expense of  some degree of user-friendliness:

(1) Jarsky_Gating_MainProgram_Fullversion.hoc:  Main program for the full version.  
(2) Jarsky_Gating_Synapses_Fullversion.hoc:  Creates and inserts synapses.

TO RUN SIMULATIONS:

There are two possibilities for running simulations which differ in
the simplicity of the graphical user interface.  For the  simplest
version run Jarsky_Gating_MainProgram_Basic.hoc.  The GUI consists of
the following panels:

(1) Stimulus:  This allows the user to vary the strength and pattern
of the Schaeffer Collatoral and Perforant  Path stimuli.  Only AMPA
synapses are activated.  The stimulus strength can vary from 0 to 100,
representing the  percentage of available synapses to be activated.

(2) Excitability:  The user may choose "weak" or "strong".

(3) Choose Seed:  The synapses are chosen randomly.  The random
numbers selected all originate from a  single seed.  The user may thus
reproduce any simulation by taking note of the seed.

(4) PSP amplitude: Record the maximum amplitude in the potential
during the simulation at three point in the  cell: soma, main-apical
dendrite and tuft.

(5) Voltages:  Shows voltage traces as a function of time (upper
panel) at six points in the cell, those mentioned  above plus three
points around the main dendritic bifurcation.  Also shows voltage as a
function of space from the  soma (0) to the tip of the tuft (lower).

(6) Shape:  A shape plot of the cell.

(7) Control:  The traditional NEURON control panel.

For the full version of the code run
Jarsky_Gating_Mainprogram_Fullversion.hoc.  The GUI  consists of the
same panels as before in additional to a panel allowing for inhibitory
synaptic input.  A panel allowing for manipulation of the active and
passive cell properties  is also present.  Synaptic stimulation is now
by cell region.  Schaeffer collatoral input and Perforant Path input 
can be simulated via "upper apical" and "tuft" input respectively.  The 
"weak" and "strong" excitable cases can now be investigated by changing 
the value of the slope in the sodium channel density "naslope" expressed 
as an increase in conductance per micron.  For "weak" choose 0 and 
"strong" choose 0.001.

NOTE: The panels of the GUI may be located differently on different
monitors.  The  user may wish to customize the location of the panels
to suit his needs.

NOTE: All .hoc code written by William Kath with the exception of 
Jarsky_Gating_Synapses*, written by Alex Roxin.

